#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def say_hello():
    ''' This function is meant for greeting people
        Input: none
        Output: none
    '''
    print("Hello Friend")

    
    
say_hello()
say_hello()

say_hello()
say_hello()

say_hello()
say_hello()


# In[ ]:





# In[ ]:





# In[ ]:


def say_hello(name):
    ''' This function is meant for greeting people
        Input: str
        Output: None
    '''
    print("Hello ", name)

    
    
say_hello("Vijay")
say_hello("John Cena")


say_hello("Saurav")
say_hello("Sachin")


# In[ ]:


say_hello()


# In[ ]:





# In[ ]:


def say_hello( name = "Random" ):
    ''' This function is meant for greeting people'''
    print("Hello ", name)


say_hello("Vijay ")

say_hello()


# In[ ]:





# In[ ]:





# In[ ]:


def say_hello(name = "Random"):
    ''' This function is meant for greeting people'''
    print("Hello ", name)

    
students = ["Vijay", "David", "XYZ", "AAAAA"]
say_hello(students)


# In[ ]:





# In[ ]:





# In[ ]:


def say_hello(name = "Random"):
    ''' This function is meant for greeting people'''
    
    for n in name:
        print("Hello ", n)

students = ["Vijay", "David", "XYZ", "AAAAA"]
say_hello(students)


# In[ ]:





# In[ ]:


def say_hello(name="Random", age=0):
    '''  say_hello(str, int) -> None   '''
        
    if age>18:
        print("Hello", name, ", You are adult and you are allowed to have beer. Cheers!! ")
    else:
        print("Hello", name, ", You are a kid. Go to your school regularly. Enjoy the best time period of your life")

        
say_hello("ABC", 5)
say_hello("John Cena",40)

say_hello()


# In[ ]:





# In[ ]:


def get_my_bmi(name,weight,height):
    ''' The function calculates the BMI of a person
        get_my_bmi(str, int,float) -> None'''
    
    bmi = weight / (height * height)
    
    if bmi < 18.5:
        status = "Under Weight"
    if 18.5 <= bmi < 24.9:
        status = "Normal"
    if 24.9 <= bmi < 29.9:
        status = "Overweight"
    if bmi >= 29.9:
        status = "Very Overweight"
    
    print(name , "has BMI of ", bmi , " and here by decalred as ", status)

#Taking user Inputs
user_name = str(input("Your name please? : "))
user_weight = int(input("Your weight please(in kg)? : "))
user_height = float(input("Your height please(in meters)? : "))

#Calling the function
get_my_bmi(user_name,user_weight,user_height)


# 

# In[ ]:





# In[ ]:



def get_my_bmi(name,weight,height):
    ''' The function calculates the BMI of a person
        get_my_bmi(str, int,float) -> None'''
    
    bmi = weight / (height * height)
    status = "none"
    
    if bmi < 18.5:
        status = "Under Weight"
    if 18.5 <= bmi < 24.9:
        status = "Normal"
    if 24.9 <= bmi < 29.9:
        status = "Overweight"
    if bmi >= 29.9:
        status = "Very Overweight"
    
    print(name , "has BMI of ", bmi , " and here by decalred as ", status)
    
#correct order of arguments
print("")
print("Calling function with correct order of paramters")
get_my_bmi("Vijay Saini", 74, 1.73)

#Incorrect order of arguments
print("")
print("Calling function with incorrect order of paramters")
get_my_bmi("Vijay Saini", 1.73, 74)

#Better Solution
print("")
print("To get rid from remebering the position:")
get_my_bmi(name="Vijay Saini", height=1.73, weight=74)
get_my_bmi(height=1.73, name="Vijay Saini", weight=74)


# In[ ]:





# In[ ]:





# In[ ]:


def addition(num1, num2):
    '''addition(int,int)-> none   '''
    print(num1 + num2)


#Store output into a variable
sum = addition(22,42)

print("Sum is:", sum)


# In[ ]:





# In[ ]:





# In[ ]:


def addition(num1, num2):
    '''addition(int,int)-> none   '''
    
    print("Function returning the sum")
    return num1 + num2
    print("Function returned the sum")

    

#Store output into a variable
sum = addition(22,42)

print("Sum is:", sum)


# In[ ]:





# In[ ]:


addition(student1_marks, stud2_marks.....stud_10000_marks......stud_15000_marks)


# In[ ]:





# In[ ]:





# In[ ]:


def my_func(*args):
    print(args)
    
my_func(21,3,4,3,4,55,5,5,5,10,34)


# In[ ]:





# In[ ]:





# In[ ]:


def average(*numbers):
    '''  The function returns average of student marks
            average(int) -> int   '''
    
    sum=0
    for num in numbers:
        sum = sum + num
    
    print("Type of numbers argument: ",type(numbers))
    count_of_numbers = len(numbers)
    
    print("Sum is:", sum)
    print("total numbers",count_of_numbers)
    
    average = sum / count_of_numbers
    
    
    return average
    

#Store output into a variable
avg = average(22,42,32,43,46,56,67,58,32,54,23,57,99,97,32,32,3,2,43,4,111111)
print("Average is:", avg)


# In[ ]:





# In[ ]:


#Another example to understand  *args
def sayHello(*names):
    '''greet people whose name is passed'''
    
    for name in names:
        print("Hello ", name)

sayHello("David", "Sam", "Python", "Tiger")


# In[ ]:





# In[ ]:


#Example: **kwargs demo

def myfunc(**fav_dishes):
    
    print(type(fav_dishes))
    print(fav_dishes)
    
    for key,value in fav_dishes.items():
        print( key , " likes to eat ", value)
        
myfunc(Sam="Chicker Burger", ABC="Veg Curry", Amit="Paneer Chilly")


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[138]:


# Python program to deomstrate *args with first extra argument : Correct way
def myFunc(arg1, *args): 
    print ("First argument :", arg1) 
    for arg in args:
        print("other argument through *argv :", arg) 
  
myFunc('Class VII Students: ', 'Ram', 'Shyam', 'Suresh', "Ramesh") 


# In[ ]:





# In[139]:


# Python program to deomstrate *args with first extra argument : Throws Error
def myFunc(*args, arg1): 
    print ("argument :", arg1) 
    for arg in args:
        print("other argument through *args :", args) 
  
myFunc('Ram', 'Shyam', 'Suresh', "Ramesh",'Class VII Students:') 


# In[ ]:





# In[ ]:





# In[ ]:





# In[140]:


# Python program to deomstrate  **kwargs for variable number of keyword arguments with one extra argument.  Correct way
  
def myFunc(arg1, **kwargs):
    print(arg1)
    print(kwargs)

 

myFunc("Hello World", MyCourse1 =':PowerShell', MyCourse2 =':Advanced Scripting', MyCourse3=':AD', MyCours4=':Python') 


# In[141]:


# Python program to deomstrate  **kwargs for variable number of keyword arguments with one extra argument.  : Throws Error

def myFunc(**kwargs, arg1):
    print(arg1)
    print(kwargs)

myFunc(MyCourse1 =':PowerShell', MyCourse2 =':Advanced Scripting', MyCourse3=':AD', MyCours4=':Python', "Hello World") 


# In[ ]:





# In[ ]:





# In[142]:


# Python program to deomstrate  **kwargs for variable number of keyword arguments with one extra argument.: Correct way

def myFunc(*args, **kwargs):
    print(args)
    print(kwargs)

myFunc('Ram', 'Shyam', 'Suresh', FavSports =':Cricket', myName =':Vijay') 


# In[ ]:





# In[143]:


# Python program to deomstrate  **kargs for variable number of keyword arguments with one extra argument.  : Throws Error
  
def myFunc(**kwargs, *args):
    print(args)
    print(kwargs)

myFunc( FavSports =':Cricket', myName =':Vijay', 'Ram', 'Shyam', 'Suresh',) 


# In[ ]:




