# Important constant
VIJAY_CONSTANT = 21
SOME_OTHER_CONSTANT = 100.22
VALUE_OF_PI = 3.14

def addition(a,b):
    return(a+b)

def subtraction(a,b):
    return(a-b)

def multiply(a,b):
    return(a*b)

def divide(a,b):
    return(a/b)

def remainder(a,b):
    return(a%b)	


print("Result of addition(10,5) is: ",addition(10,5))
print("Result of subtraction(10,5) is: ",subtraction(10,5))
print("Result of multiply(10,5) is: ",multiply(10,5))
print("Result of divide(10,5) is: ",divide(10,5))
print("Result of remainder(10,5) is: ",remainder(10,5))
