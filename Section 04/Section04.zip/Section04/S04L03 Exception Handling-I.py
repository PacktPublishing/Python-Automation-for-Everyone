#!/usr/bin/env python
# coding: utf-8

# In[ ]:


result  = 10/0


# In[ ]:





# In[ ]:


list = [12,3,4]
print(list[1000])


# In[ ]:





# In[ ]:


"Str" + 100


# In[ ]:


print( 10/0 )


# In[ ]:





# In[ ]:


result = 10/5


# In[ ]:


result = 10/0


# In[ ]:





# In[ ]:


try:
 result = 10/0
 
except ZeroDivisionError:
 print("division by zero!")

else:
 print("result is", result)

finally:
 print("executing finally clause")


# In[ ]:





# In[ ]:


# calulating area of Sphere
# A = 4πr2  (value of π=3.14)

#Example: Invalid program as not properly type casted

radius = input("Enter the radius of your sphere")
area = 4 * 3.14 * radius * radius
print("Area: ", area)


# In[ ]:





# In[ ]:


# calulating area of Sphere

radius = float(input("Enter the radius of your sphere: "))
area = 4 * 3.14 * radius * radius
print("Area: ", area)


# In[ ]:





# In[ ]:


#Example: ValueError Exception handled
try:
    radius = float(input("Enter the radius of your sphere(in centi meters): "))
    
except ValueError:
    print("Looks like you have not entered a valid number. Kindly provide a number value")


# In[ ]:





# In[ ]:


#Example: We can have multiple except statements
try:
    radius = float(input("Enter the radius of your sphere(in centi meters): "))
    
except ValueError:
    print("Looks like you have not entered a valid number. Kindly provide a number value")
except SomeError:
    print("SomeError")
except AnotherError:
    print("AnotherError")


# In[ ]:





# In[ ]:


#Example: Default except block
try:
    radius = float(input("Enter the radius of your sphere(in centi meters): "))
    
except ValueError:
    print("Looks like you have not entered a valid number. Kindly provide a number value")

except:
    print("Something went wrong. We cant help you with calcuating the area of your sphere at this moment")
    


# In[ ]:





# In[ ]:


#Default Except block has to be the last except block, else we get SyntaxError

try:
    radius = float(input("Enter the radius of your sphere(in centi meters): "))

except:
    print("Something went wrong. We cant help you with calcuating the area of your sphere at this moment")

except ValueError:
    print("Looks like you have not entered a valid number. Kindly provide a number value")
    


# In[ ]:





# In[ ]:





# In[ ]:


#Example: Else Block if no exception is raised
try:
    radius = float(input("Enter the radius of your sphere(in centi meters): "))
    
except ValueError:
    print("Looks like you have not entered a valid number. Kindly provide a number value")
    # Do something, ValueError has occurred
except:
    print("Something went wrong. We cant help you with calcuating the area of your sphere at this moment")

else:
    area = 4 * 3.14 * radius * radius
    print("Area: ", area)


# In[ ]:





# In[ ]:


#Example: Else Block if no exception is raised
try:
    radius = float(input("Enter the radius of your sphere(in centi meters): "))
    
except ValueError:
    print("Looks like you have not entered a valid number. Kindly provide a number value")
    # Do something, ValueError has occurred

except NameError:
    print("Looks like you have not entered a valid number. Kindly provide a number value")
     # Do something, NameError has occurred
    
except:
    print("Something went wrong. We cant help you with calcuating the area of your sphere at this moment")
    # Do Something, Some error occurred
else:
    area = 4 * 3.14 * radius * radius
    print("Area: ", area)


# In[ ]:


#=======================#
#===END OF LECTURE====#
#=======================#

