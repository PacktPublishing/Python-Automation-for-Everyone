#!/usr/bin/env python
# coding: utf-8

# In[ ]:


try:
    a = int(input("Enter a positive number: "))
           
except Exception:
    print("Exception occurred")
else:
    print("OK")


# In[ ]:





# In[ ]:





# In[ ]:


try:
    a = int(input("Enter a positive number: "))
       
    if a==11:
        raise ValueError("number 11 is reserved for Vijay. You cant use it as per constitution.")
     
    if( a < 0):
        raise Exception('Hello! Thats not a positive integer. You are lying')
    

except ValueError:
    print("You must have dared to enter Vijay's favorite number. You are not allowed to do this.")
    print(" Value Error Occurred")
    
except Exception:
    print("Some Error Occurred")
else:
    print("Thank You. God bless you!")


# In[ ]:


10/0


# In[ ]:


#demo: AS keyword, 
#A simple example
try:
    res = 10/0
    
except Exception as e:
    print("Here is the Error message: ", e)

else:
    print("Thank You. God bless you!")


# In[ ]:





# In[ ]:


#demo: AS keyword
try:
    a = int(input("Enter a positive number: "))
    
    if( a < 0):
        raise Exception('Hello! Thats not a positive integer. You are lying')
        
    if a==11:
        raise ValueError("number 11 is reserved for Vijay. You cant use it")

except ValueError as ve:
    print("You must have dared to enter Vijay's favorite number. You are not allowed to do this.")
    print("Err:", ve)
    
except Exception as e:
    print("Error message: ", e)

else:
    print("Thank You. God bless you!")


# In[ ]:


10/0


# In[ ]:





# In[ ]:


# Example
# Handle all other exceptions including ValueError

try:
    radius = float(input("Enter the radius of your sphere(in centi meters): "))
    
    if radius <= 0:
        raise Exception('Radius cannot be less than equal to zero')

except ValueError as err:
    print("Looks like you have not entered a valid number. Kindly provide a number value")
    print("Error Message: ", err)

except Exception as e:
    print("Something went wrong. We cant help you with calcuating the area of your sphere at this moment")
    print("Error Message", e)

else:
    area = 4 * 3.14 * radius * radius
    print("Area: ", area)


# In[ ]:





# In[ ]:





# In[ ]:


#Database Operations

#step1: 
connect_to_database()
    
#step2: 
execute_queries()

#step3: 
close_connection()


# In[ ]:





# In[ ]:


#Database Operations

try:
    #step1: 
    connect_to_database()

    #step2: 
    execute_queries()

    #step3: 
    close_connection()
except:
    handle_Error()
    


# In[ ]:





# In[ ]:


#Database Operations: Closing connection inside except block

try:
    #step1: 
    connect_to_database()

    #step2: 
    execute_queries()

except:
    handle_Error()
    
    #step3: 
    close_connection()
    


# In[ ]:





# In[ ]:


#Database Operations: Correct Approach. use of finally block ensure that database(resource) is closed after using it

try:
    #step1: 
    connect_to_database()

    #step2: 
    execute_queries()
except:
    handle_Error()

finally:
    #step3:
    close_connection()
    


# In[ ]:





# In[ ]:





# In[ ]:


# Example: Finally Block

try:
    radius = float(input("Enter the radius of your sphere(in centi meters): "))
    
    if radius <= 0:
        raise Exception('Radius cannot be less than equal to zero')

except ValueError as err:
    print("Looks like you have not entered a valid number. Kindly provide a number value")
    print("Error Message: ", err)
    
except:
    print("Something went wrong. We cant help you with calcuating the area of your sphere at this moment")

else:
    area = 4 * 3.14 * radius * radius
    print("Area: ", area)

finally:
    print("=========You know what, I am so good that I always execute===========")
    print("Hope you had nice experience with our calculation services. Exiting  now")


# In[ ]:





# In[ ]:


def myFunc(a,b):
    return(a+b)

print( myFunc(12,20) )


# In[ ]:


def myFunc(a,b):
    return(a+b)

print( myFunc() )


# In[ ]:


print( myFunc() )


# In[ ]:


def myFunc(a,b):
    return(a+b)

try:
    print( myFunc() )
except:
    print("Something went wrong while calling the function")


# In[ ]:





# In[ ]:


def myFunc(a,b):
    try:
        return(a+b)
    except:
        print("unable to return sum")


print( myFunc() )


# In[ ]:





# In[ ]:


#Example

x = 10
y = 2
try:
    result = x/y
    print("Result")
except:
    print("Except")
else:
    print("Else")
finally:
    print("Done")


# In[ ]:


try:
   # Potentially dangerous code

except SomeException:
    # Handle SomeException
    
except (anotherException, YetAnotherException):
    # Handle anotherException and YetAnotherException
    
except:
    # Handle any other exception , which is 
    # not handled above me.
    
else:
    # No Exception occurred then only I get executed

finally:
    # I always get executed, Use me for clean up of
    #  your code like closing file, database etc


# In[ ]:





# In[ ]:


#=======================#
#===END OF LECTURE-II====#
#=======================#

