#!/usr/bin/env python
# coding: utf-8

# In[ ]:



def my_func():
   pass


# In[ ]:





# In[ ]:



#Example:User defined function

def my_func():
	''' This is docstring. This breifly explain the function input/output'''
	print("Hello World")


# In[ ]:


#Access doc string about a function

# User defined function
print(my_func.__doc__)

print("=================================")
print("")

#Just to compare accessing docstring of an inbuilt function
print("Range Function's docstring:")
print(range.__doc__)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


help(my_func)


# In[ ]:





# In[ ]:


def my_func():
    ''' This function is containing some very important formula of this world'''
    print("Hello World")
    print("I am your function. You can see I am quite complex")
    print("Thank you for calling me. God Bless you")
    print("Call me again and again as many times you want in future also")
    print(".......................................................................")


# In[ ]:


my_func()


# In[ ]:





# In[59]:


def my_func():
    ''' This function is containing some very important formula of this world'''
    print("Hello Friend")
    print("I am your function. You can see I am quite complex")
    print("Thank you for calling me. God Bless you")
    print("Call me again and again as many times you want in future also")
    print(".......................................................................")

    
    
    
print("**********************")
print("I am doing something")
my_func()

print("calling function again")
my_func()

print("Yet again")
my_func()
print("**********************")


# In[ ]:





# In[ ]:



print("**********************")
print("I am doing something")

print("Hello World")
print("I am your function. You can see I am quite complex")
print("Thank you for calling me. God Bless you")
print("Call me again and again as many times you want in future also")
print(".......................................................................")


print("calling function again")

print("Hello World")
print("I am your function. You can see I am quite complex")
print("Thank you for calling me. God Bless you")
print("Call me again and again as many times you want in future also")
print(".......................................................................")

print("Yet again")

print("Hello World")
print("I am your function. You can see I am quite complex")
print("Thank you for calling me. God Bless you")
print("Call me again and again as many times you want in future also")
print(".......................................................................")

print("**********************")

