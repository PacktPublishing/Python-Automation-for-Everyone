

#Example 1 a.)
import package.sub_package2.module2 #importing a module
package.sub_package2.module2.module2_method()  # Calling a method from module

#Example 1 b.)
import package.sub_package2.module2 as mod_name #importing a module with alias name
mod_name.module2_method()  # Calling a method from module


#Example 2.) 
from package.sub_package1.module1 import * #importing all methods from a module
module1_method()


#Example 3.) 
from package.my_module import my_module_method  # Importing the function from main module
my_module_method() # Calling the function defined inside 