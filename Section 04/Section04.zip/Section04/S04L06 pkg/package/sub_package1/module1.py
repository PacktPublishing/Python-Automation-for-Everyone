def module1_method():
	print("I am a method from module1 which is inside subpackage1")