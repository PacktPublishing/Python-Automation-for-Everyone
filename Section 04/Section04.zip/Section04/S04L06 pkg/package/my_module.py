def my_module_method():
	print("I am a method from my_module which is inside package")