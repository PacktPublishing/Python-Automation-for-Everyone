def module2_method():
	print("I am a method from module2 which is inside subpackage2")