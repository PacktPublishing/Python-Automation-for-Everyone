pip install mysql-connector

Python-Database Interaction
C:\Users\1019080\AppData\Local\Programs\Python\Python37-32\python.exe

S06Ex01 Create Database Table

import mysql.connector

connection = mysql.connector.connect(host="localhost", 
                                     user="root", 
                                     passwd="", 
                                     database="mydb")
mycursor = connection.cursor()


mycursor.execute("CREATE TABLE Test_Table (username VARCHAR(100), password VARCHAR(120))")
