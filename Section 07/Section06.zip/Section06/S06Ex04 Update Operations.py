#Step1: Update Statement -> Example1
import mysql.connector

connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
cursor = connection.cursor()

sql = "UPDATE MyStudentsData SET Student_Name = 'Vijay' WHERE student_id = '2'"

cursor.execute(sql)
connection.commit()
print(cursor.rowcount, "record(s) affected")



#Step2: Update Statement -> Example2
import mysql.connector

connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
cursor = connection.cursor()

sql = "DELETE FROM MyStudentsData WHERE student_id = 1"

cursor.execute(sql)
connection.commit()
print(cursor.rowcount, "record(s) deleted")

cursor.close()
cursor.close()