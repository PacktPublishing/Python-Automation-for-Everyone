#Step1: Insert Statement -> insert 1 row at a time
import mysql.connector

connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
cursor = connection.cursor()

#cursor.execute("SELECT * from mystudentsdata WHERE student_name='" + stud_name + "'")

sql = "INSERT INTO MyStudentsData VALUES (%s, %s, %s, %s, %s)"
val = (10, "Jon Snow", "Learning Task Automation", "In-Progress","True")
cursor.execute(sql, val)


#Commit: to end your current transaction and make the changes permanent(cannot be reversed)
connection.commit()

print(cursor.rowcount, "row was inserted.")

cursor.close()
connection.close()

#========================================================================================





#Step2: Insert Statement -> insert many rows at a time
import mysql.connector

connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
cursor = connection.cursor()
sql = "INSERT INTO MyStudentsData VALUES (%s, %s, %s, %s, %s)"
val = [
  (100, "Kim", "Python For Everyone", "Completed","True"),
  (101, "Ravi", "Active Directory Managment using PowerShell", "Not Started","False"),
  (102, "Mark", "Learning Task Automation using PowerShell", "In-Progress","True"),
  (103, "Sam", "Advanced Scripting using PowerShell", "In-Progress","True"),
]

cursor.executemany(sql, val)
connection.commit()
print(cursor.rowcount, " rows were inserted.")
#========================================================================================






#Step 3: Exception Handling
import mysql.connector
try:
  connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
  cursor = connection.cursor()
  sql = "INSERT INTO MyStudentsData VALUES (%s, %s, %s, %s, %s)"
  val = (12, "Pooja", "Advanced Scripting", "In-Progress", "True")
  cursor.execute(sql, val)
  connection.commit()

except Exception as err:
    print("Exception occurred.\nError Message: ",err)
finally:
  cursor.close()
  connection.close()
#========================================================================