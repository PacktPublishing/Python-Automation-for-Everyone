
CREATE TABLE IF NOT EXISTS `mystudentsdata` (
  `Student_ID` varchar(100) NOT NULL,
  `Student_Name` varchar(100) NOT NULL,
  `Course_Name` varchar(100) NOT NULL,
  `Course_Completion_Status` varchar(100) NOT NULL,
  `Review_Status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `mystudentsdata` (`Student_ID`, `Student_Name`, `Course_Name`, `Course_Completion_Status`, `Review_Status`) VALUES
('1', 'Vijay', 'Python for Everyone', 'Completed', ''),
('2', 'Vijay', 'Advanced Scripting using PowerShell', 'Completed', ''),
('3', 'Sam', 'Active Directory Managment using PowerShell', 'Not Started', 'False'),
('4', 'Sam', 'Learning Task Automation using PowerShell', 'In-Progress', 'True'),
('5', 'Sam', 'Advanced Scripting using PowerShell', 'In-Progress', 'True'),
('6', 'Ram', 'Python For Everyone', 'In-Progress', 'True'),
('7', 'Pooja', 'Advanced Scripting using PowerShell', 'In-Progress', 'True'),
('8', 'Pooja', 'Python For Everyone', 'In-Progress', 'True'),
('9', 'Ram', 'Learning Task Automation using PowerShell', 'Wrong Update', 'I am incorrect Value');

