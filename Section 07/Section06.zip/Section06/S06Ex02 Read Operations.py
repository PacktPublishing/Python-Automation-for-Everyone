#======================================================================== 
#Step1: Select Statement -> Initial

import mysql.connector

connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
cursor = connection.cursor()
cursor.execute("SELECT * FROM MyStudentsData")
result = cursor.fetchall()
print(result)

for res in result:
  print(res)
  
  
  
  
# ========================================================================
# Step1: Select Statement -> Initial

import mysql.connector

connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
cursor = connection.cursor()
cursor.execute("SELECT * FROM MyStudentsData")
result = cursor.fetchall()

for res in result:
    stud_name = res[1]
    course_name = res[2]
    course_status = res[3]
    if course_status == 'Completed':
        print("Well done", stud_name,  "Congratulation on completing course: ", course_name)

  
  

#========================================================================   
#Step2: Select Statement -> Where Clause 
import mysql.connector
connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
cursor = connection.cursor()
cursor.execute("SELECT * FROM MyStudentsData where Student_Name='Sam'")
result = cursor.fetchall()

for res in result:
  print(res)
 
 
 
 
 
 
#========================================================================  
#Step3: Select Statement -> Where Clause, Taking user inputs(SQL Injection)
import mysql.connector
connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
cursor = connection.cursor()

stud_name = input("Please enter the name of student you are interested in:")
cursor.execute("SELECT * from mystudentsdata WHERE student_name='" + stud_name + "'")
result = cursor.fetchall()

for res in result:
  print(res)

  
#For SQL Injection, Enter: 
#		vijay'; Drop table test_table; 
  
  
  
  
  
 #======================================================================== 
#Step4: Select Statement -> Where Clause, Taking user inputs(Fixed SQL Injection)
import mysql.connector

connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
cursor = connection.cursor()

stud_name = input("Please enter the name of student youde are interested in:")
cursor.execute("SELECT * FROM MyStudentsData where Student_Name=%s", (stud_name,))
result = cursor.fetchall()

for res in result:
    print(res)
  
  

  
  
  
  

#======================================================================== 
#Step5: Seperate the SQL and value  
import mysql.connector

connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
cursor = connection.cursor()

sql="SELECT * FROM MyStudentsData where Student_Name=%s"
stud_name = ("vijay",)  # Search Keyword

cursor.execute(sql, stud_name)
result = cursor.fetchall()

for res in result:
    print(res)
  
  
  
   
  
#========================================================================   
#Step 6: Exception Handling
import mysql.connector
try:
    connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
    cursor = connection.cursor()
    sql = "select * from mystudentsdata"
    cursor.execute(sql)
	result = cursor.fetchall()

	for res in result:
		print(res)


except Exception as err:
    print("Exception occurred.\nError Message: ",err)
	
finally:
    cursor.close()
    connection.close()


