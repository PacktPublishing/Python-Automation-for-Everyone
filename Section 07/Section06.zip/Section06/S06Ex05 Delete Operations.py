#Step1  Delete Statement -> Initial
import mysql.connector

connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
cursor = connection.cursor()

sql = "DELETE FROM MyStudentsData WHERE student_id = 1"

cursor.execute(sql)
connection.commit()
print(cursor.rowcount, "record(s) deleted")

#========================================================================




#Step2  Delete Statement -> Exception Handling
import mysql.connector
try:
  connection = mysql.connector.connect(host="localhost", user="root", passwd="", database="mydb")
  cursor = connection.cursor()
  sql = "DELETE FROM MyStudentsData WHERE student_id = %s"
  val = (12,)
  cursor.execute(sql, val)
  connection.commit()

except Exception as err:
    print("Exception occurred.\nError Message: ",err)

finally:
  print(cursor.rowcount, "record(s) deleted")
  cursor.close()
  connection.close()
#========================================================================
