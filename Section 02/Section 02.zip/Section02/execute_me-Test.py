
name = input("Hello Sir! Your name please: ")
age = input("Please enter your age: ")


#Printing the output
print(name, " is ", age, " years old" )