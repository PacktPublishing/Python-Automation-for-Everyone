input()
input("Hello Sir! Enter your name please:")


name = input("Hello Sir! Your name please:")


name = input("Hello Sir! Your name please:")
age = input("Please enter your age:")

print(name, age)




#Printing the output
print(name, " is ", age, " years old" )