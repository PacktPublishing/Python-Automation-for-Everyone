
# coding: utf-8

# In[1]:


varA = 1000


# In[3]:


print(varA)


# In[4]:


varA


# In[5]:


type(varA)


# In[6]:


varA  = "This is a String"


# In[ ]:


type(varA)


# In[15]:


a=1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000


# In[16]:


ab = a*a*a*a


# In[20]:


print(type(ab))


# In[18]:


type(ab)


# In[19]:


a=11.32


# In[21]:


print(type(ab))


# In[25]:


'''
fgtftgfgy
'''

hfvhhgg=6789


# In[26]:


a = 10
b = 100
a+b


# In[31]:


a = 10
b = 100
print(a+b)



a = 1000
b = 900
print(a-b)


# In[36]:


#Sum
a = 100
b = 50
sum = a + b
print(sum)


#Difference
a = 100
b = 50
diff = a - b
print(diff)


#Multiply
a = 100
b = 50
product = a * b
print( product )


#Divide
a = 100
b = 50
div = a / b
print( div )


#Moduls Operator
a = 100
b = 50
remainder = a % b
print( remainder )


# In[37]:


#Sum
a = 100
b = 50
sum = a + b
print("Sum: ",sum)


#Difference
a = 100
b = 50
diff = a - b
print(diff)


#Multiply
a = 100
b = 50
product = a * b
print( product )


#Divide
a = 100
b = 50
div = a / b
print( div )


#Moduls Operator
a = 100
b = 50
remainder = a % b
print( remainder )

