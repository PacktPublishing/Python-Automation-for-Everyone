#DIR Function

#Ex01 Dir Without any parameter:
dir()



import math
dir()



#HELP FUNCTION

help()

help("modules")



#The help() method is used for interactive use. It's recommenced to try it in your interpreter when you need help to write Python program and use Python modules.

##If string is passed as an argument, the given string is looked up as the name of a module, function, class, method, keyword, or documentation topic, and a help page is printed.
 help(str)
 help("")
 
 help(list)
 
 help(dict)
 
 
 help(print)
 
 
 help([1, 2, 3])

 
 
 help('print')
 
 
 help('def')


  
 
 
 
 
 help(str.index)
 

 
main_string = "This is a string which is contain substring. We can use Index method to search the substring"
main_string.index("substring")
main_string.index("testing")
main_string.index("substring",35,100)


 
 from math import * 
    help('math.pow’)

	help(range.index)
##no argument is passed to help(): If no argument is passed, Python's help utility (interactive help system) starts on the console


str_object = "This is a string"
type(str_object)
len(str_object)


list=[3434,34,34,3,4,3,4]
type(list)
len(list)



