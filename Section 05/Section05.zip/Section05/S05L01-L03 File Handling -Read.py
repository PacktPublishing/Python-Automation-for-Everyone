#!/usr/bin/env python
# coding: utf-8

# In[280]:


pwd # Check your present working directory


# In[279]:


cd C:\Python\Section04


# In[ ]:





# In[ ]:


# Opening file available at present working directory
file_obj = open("TestFile.txt", 'r',  encoding = 'cp1252')


# In[262]:


# Opening file from another directory
file_obj = open("C:/Python/Section04/test.txt", 'r',  encoding = 'cp1252')


# In[ ]:


#object Introspection
print( dir(file_obj))


# In[263]:


#object Introspection
help( file_obj )


# In[ ]:


#object Introspection
type( file_obj )


# In[ ]:





# In[ ]:


# Python code to demonstrate read() method 
file = open("TestFile.txt", "r")  
print(file.read())


# In[ ]:


# Python code to demonstrate read() method 
file = open("TestFile.txt", "r")  
print(file.read(100))


# In[ ]:


print(file.read(100))


# In[ ]:


print(file.read(100))


# In[ ]:


print("cursor position is ", file.tell()) # get the position of cursor using tell()


# In[ ]:


#change cursor to position 0
file.seek(0)
print("cursor position is ", file.tell()) # change the position of cursor using seek()


# In[ ]:


#change cursor to position 0
file.seek(250)
print("cursor position is ", file.tell())


# In[ ]:


#Reading the chunk of 100 characters from current cursor position
print("cursor position is ", file.tell())
print(file.read(100)) 
print("cursor position is ", file.tell())


# In[ ]:





# In[ ]:


# Python code to illustrate read() mode 
file = open("TestFile.txt", "r")  
print( file.readline() ) # read the first line


# In[ ]:


# Python code to illustrate readline() mode 
file = open("TestFile.txt", "r")  
print( file.readline() ) # read the first line


# In[ ]:


print( file.readline() ) # read the second line
print( file.readline() ) # read the third line
print( file.readline() ) # read the fourth line


# In[ ]:


#Reading the chunk of 100 characters from current cursor position
print("cursor position is ", file.tell())
file.seek(0) #Changing the cursor position

print(file.readline()) 
print("cursor position is ", file.tell())


# In[ ]:


# Python code to illustrate read() mode 
file = open("TestFile.txt", "r")  
print( file.readline(10) ) # read the specified number of charcters from only first line


# In[ ]:





# In[ ]:


help(file.readlines)


# In[ ]:


# Python code to illustrate read() mode 
file = open("TestFile.txt", "r")  
print( file.readlines() ) #return the list of all lines (each new line as a new item in the list)


# In[ ]:


file = open("testfile.txt", "r") 
print(file.readlines(200)) # Return the list of lines within specified number of characters


# In[ ]:


# Python code to illustrate read() mode 
file = open("TestFile.txt", "r")  
print( file.readlines()[3] ) # read a line by line number


# In[ ]:


# Python code to illustrate readline() mode 
file = open("TestFile.txt", "r")  
print( file.readline() ) 
print( file.readline() ) 
print( file.readline() ) 
print( file.readline() ) 


# In[ ]:


# Python code to demonstrate readlines() method 
file = open("TestFile.txt", "r")  
print( file.readlines()[2:7] ) #Read certain range of lines


# In[ ]:





# In[ ]:


#Read the lines and use for loop to iterate over each line
file = open("testfile.txt", "r") 
for l in file.readlines():
    print("Hello " , l)


# In[ ]:





# In[ ]:


#direct way to access each line in the file
file = open("TestFile.txt", "r") 
for line in file: 
    print("-",line)


# In[ ]:





# In[ ]:


#direct way to access each line in the file
file = open("TestFile.txt", "r") 
print("Is file closed?", file.closed)   # Checking if file is closed. Just to demonstarte. We need not to do it always

print(file.readlines()[1])

file.close() #closing the file


#check if file is close. Good to know but we need not to be so cautious all the time
print("Is file closed?", file.closed) # Checking if file is closed. Just to demonstarte. We need not to do it always


# In[ ]:


print(dir(file))


# In[ ]:





# In[ ]:





# In[ ]:


my_file_handle=open("I_Dont_Exist.txt")


# In[ ]:


try:
    my_file_handle=open("TestFile.txtw")
    print(my_file_handle.read(3))
except FileNotFoundError:
    print("File not found or path is incorrect")
except IOError:
    print("Something went wrong while reading the file")
finally:
    my_file_handle.close()
    print("exitting now")


# In[ ]:





# In[ ]:





# In[ ]:


#Use of WITH keyword
with open("testfile.txt") as file:  
    data = file.readline()

print(data)
print(file.closed) #Proof that file is closed automatically


# In[ ]:


with open("testfile.txt") as file:  
    data = file.read()
    print(data)
    #do something with data 


# In[ ]:





# In[ ]:





# In[ ]:


#Splitting Lines in a Text File

with open("testfile.txt", "r") as f:
    data = f.readlines()
 
for line in data:
    words = line.split()
    print(words)


# In[ ]:


#Example: Splitting Lines in a Text File

with open("testfile.txt", "r") as f:
    data = f.readlines()
 
for line in data:
    words = line.split("#") #breaking the string(line) by '#' as delimiter
    print(words)


# In[ ]:





# In[ ]:


#Example: Splitting Lines in a Text File

with open("marks_sheet.txt", "r") as f:
    data = f.readlines()
 
for line in data:
    tmp = line.split(",")
    print(tmp)


# In[ ]:


#Example2: Splitting Lines in a Text File

with open("marks_sheet.txt", "r") as f:
    data = f.readlines()
 
for line in data:
    tmp = line.split(",") #breaking the string(line) by ',' as delimiter
    
    name = tmp[0]
    marks = int(tmp[1])
    
    if marks > 60:
        print(name , " has successfully cleared the examination ")
    else:
        print(name , " has failed to clear the examination ")

