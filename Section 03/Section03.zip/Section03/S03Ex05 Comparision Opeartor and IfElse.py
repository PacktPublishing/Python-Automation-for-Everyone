x = 5
y = 20


x == y   # False
x != y   # True

x = 20
y = 20
x == y   # True


x = 5
y = 20
# Output: x > y is False
print('x > y  is',x>y)

# Output: x < y is True
print('x < y  is',x<y)

# Output: x == y is False
print('x == y is',x==y)

# Output: x != y is True
print('x != y is',x!=y)

# Output: x >= y is False
print('x >= y is',x>=y)

# Output: x <= y is True
print('x <= y is',x<=y)




str1 = 'PYTHON'
str2 = 'python'

str1 == str2    # False  because it is case sensitive

str1.casefold() == str2.casefold()    # True , Case-insensitive comparison




x=10
y=10

print('x is y is', x is y )


list1 = [10,20]
list2 = [10,20]

list1 == list2   	
list1 is list2		


id(list1)
id(list2)



#lOGICAL Operators
x = True
y = False

# Output: x and y is False
print('x and y is',  x and y)

# Output: x or y is True
print('x or y is',  x or y)

# Output: not x is False
print('not x is',  not x)

print((9 > 7) and (2 < 4))  # Both original expressions are True
print((8 == 8) or (6 != 6)) # One original expression is True
print(not(3 <= 1)) 


print((-0.2 > 1.4) and (0.8 < 3.1)) # One original expression is False
print((7.5 == 8.9) or (9.2 != 9.2)) # Both original expressions are False       
print(not(-5.7 <= 0.3)) 









#If loop
a = 10
b = 5
if b > a:
  print("b is greater than a")
  
  
#If-Else loop
a = 10
b = 5
if b > a:
  print("b is greater than a")
else:
  print("b is NOT greater than a")
 


 
 
#If-elif-else
age = int(input("What is your age? :  "))

if 0 < age < 10::
  print('You are a lovely kid')
elif 10 <= age < 18:
  print('Go to your school regularly')
elif 18 <= age < 60:
  print('Cheers!!!...You are allowed to drink beer and cast your vote')
elif age >= 60:
  print('Congratulations!! You are eligible for senior citizen benefits')
else:
  print('I did not get your age. Are you human being')
  
  