list = [ 'Student', 567 , 12.34, "This is my favorite Python class" ]

anotherList = [2018, 'I Love', 'Programming']


#Type of object
type(list)

#Directory function
dir(list)

#Print each dir item in new line:
for i in dir(list): print(i) 

 
print(list)          # Prints complete list
print(list[0])       # Prints first element of the list
print(list[1:3])     # Prints elements starting from 2nd till 4th 
print(list[2:])      # Prints elements starting from 3rd element
print(anotherList * 2 )  # Prints list two times
print(list + anotherList) # Prints concatenated lists


#Python help
help(list) #or help([])


list[0] = "A new value"


#
list.append("Something New")
list.append([3232,3232])


anotherList.clear()   #Clear the list elements



#Wrong way of clonning
listA = [10,20,30]
listB = listA

id(listA)
id(listB)

listB = listA.copy()



list = [10, 20, 30, 10, "a", "b", "c"]
list.count(10)
list.count("a")


#Extend
list = [10, 20, 30]
list.append([40,50])
list.extend([40,50])

#Index L.index(value, [start, [stop]]) -> integer -- return first index of value. Raises ValueError if the value is not present.
list = ["a", "b", 1,2,"a","b"]
list.index(1)
list.index("a")
list.index("a", 2)
list.index("a", 2, 5)


#Insert 
list = ['a', 'b', 1, 2, 'a', 'b']
list.insert(1, "New Value")


#pop  : remove and return item at index (default last).   Raises IndexError if list is empty or index is out of range.
list.pop(1)

#remove  :remove first occurrence of value. Raises ValueError if the value is not present.
 list = ['a', 'b', 1, 2, 'a', 'b']
 list.remove("b")
 
 
 #reverse  
 list = ['a', 'b', 1, 2, 'a', 'b']
 list.reverse()
 list
 
 #sort
 list = ['a', 'b', 3, 1, 2, 'a', 'z']
 list.sort
  
 list = ['a', 'b','a', 'z']
 list.sort
 
 list = ['a', 'b','a', 'z', 3, 2, 1]
 list.sort