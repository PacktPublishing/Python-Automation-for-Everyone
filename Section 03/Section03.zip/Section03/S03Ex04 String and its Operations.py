str1 = 'Hello World!'
print(str1)

str = "Hello World!"
print(str2)


#Creating String -I
my_str = 'This is world's best Python course'
print(my_str)

my_str = "This is world's best Python course"
print(my_str)

# Or use escape character appropriately
using_escape_char = 'This is world\'s best Python course'
print(using_escape_char)




#Creating String -II
my_str = "My best friend told me, "Python is really a cool programming language""
print(my_str)

my_str = 'My best friend told me, "Python is really a cool programming language"'
print(my_str)

#Or use escape character appropriately
using_escape_char = "My best friend told me, \"Python is really a cool programming language\" "
print(using_escape_char)






#Creating String -III
my_str = "According to intelligent people, "This is world's best Python course""
print(my_str)

my_str = '''According to intelligent people, "This is world's best Python course"'''
print(my_str)

my_str = '''According to some intelligent people across world, 

"This is world's best

Python course :)" '''
my_str

print(my_str)


#Or use escape character appropriately
using_escape_char = "According to smart people, \"This is world\'s best \Python course ")  "
print(using_escape_char)




 
 #Other Operations
str          # complete string
str[0]       # first character of the string
str[2:5]     # characterstarting from 3rd to 5th
str[2:]      # string starting from 3rd character
str * 2      # string two times
str + "TEST" # concatenated string

string = "PYTHON PROGRAMMING"

print( string[0] ) 		#   => 'P'
print( string[6] ) 		#   => ' '
print( string[17] ) 	#   => 'G'
print( string[-1] ) 	#   => 'G'
print( string[-18] ) 	#   => 'P'
print( string[3: 8] ) 	#   =>    'HON P' 
print( string[10 : -2])	#   =>     'GRAMMI'
print( string[10 : ] )   #   =>      'PROGRAMMING'
print( string[ : 8]  )       #   =>    'PYTHON P'
print( string[ : ]  )             #   =>   'PYTHON PROGRAMMING'
 

 
 
 
#Dir function
print( dir(str) )  # or dir("")

#OUTPUT:
#'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']


#Help Function
help("")

greeting_msg = "hello Python lovers."

# capitalize
help(greeting_msg.capitalize)
# Return a capitalized version of S, i.e. make the first character have upper case and the rest lower case.

greeting_msg.capitalize()



#lower
"I am PYTHON String".lower()


#upper
"Are you enjoying Strings".upper()


#count: 
str = "I Love Python. I love Programming"
str.count("I")  # returns 2
str.count("Love") #returns 1


msg_str = "Hi There. use Casefold to convert me into LOWER LETTERS"
#casefold:  returns a string which can be used for caseless comparisions.
# This work like lower() but more aggressive nature. It will change case of even 
#non-english letter in order to make them suitble for caseless comparision
msg_str.casefold()





# All of below method returns true or false
# 'isalnum', 'isalpha', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper',
"String 123".isalnum()   # This returns false
"String".isalnum()   # This returns true 




# Strip:  Remove white spaces 
# Return a copy of the string S with leading and trailing whitespace removed.
# If chars is given and not None, remove characters in chars instead.
"  I have few white spaces in the starting".strip()
"  I have white spaces both sides  ".strip()


#Zfill:   Pad a numeric string S with zeros on the left, to fill a field of the specified width. The string S is never truncated.
"ABCD".zfill(10)



#replace 
 "If you want, you can replace me ".replace("you", "xxx")  		# replace  all instance of 'you' with 'xxx'
 "If you want, you can replace me ".replace("you", "xxx", 1) 	# replace First instance of 'you' with 'xxx'

 
 
 
 
 # find
"Can some one find XXX in me".find('XXX')  			#returns 18
"Can some one find XXX in me".find('XXX', 0, 30)	#returns 18
"Can some one find XXX in me".find('XXX', 0, 10)	#returns -1


# format

# formatting a string using a numeric constant 
"Hello Friend.  I am {} years old !".format(26)

greeting_msg = "Hello Friend.  I am {} years old !"
greeting_msg.format(26)
greeting_msg.format(20)
greeting_msg.format(40)


# 
"My name is {} and you are learning {} using version {}".format("Vijay", "Python", 3)

statment = "My name is {} and you are learning {} using version {}"
statment.format("Vijay", "Python", 3)




# Split:
# Return a list of the words in S, using sep as the delimiter string.  If maxsplit is given, at most maxsplit
# splits are done. If sep is not specified or is None, any whitespace string is a separator
# and empty strings are removed from the result.

"student1,student2,student3,student4".split(",")
"data1#data2#data3".split("#")
"message1 #INFO# message2 #INFO# message3 ".split("#INFO#")
