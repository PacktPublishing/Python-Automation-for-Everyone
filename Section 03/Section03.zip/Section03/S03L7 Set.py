
# Create set
set_A = {1,2,3,4,1,2}
set_B = {1,2,3,7}
print(set_A)


#Directory Function
dir(set_A)
#add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update', 'isdisjoint', 'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update', 'union', 'update']

#Print each dir item in new line:
for i in dir(set_A): print(i) 


#Type Function
type(set_A)


#Help
help(set_A)


#Help About a particular function
help(set_A.union()) #or help({}.union())



# Add a new item to the set
set_A.add(10)


# Add multiple items to the set
set_A.update([1,2,4,6,9])



# Delete all items from a set
set_ex = {1,2,3,4,1,2}
set_ex.clear()



# Clone a set
set_A = {1,2,3,4,1,2}
set_copy = set_A.copy()



# Remove an element from a set by its index number; it must be a member. If the element is not a member, RAISE A KeyError.
set_A = {1,2,3,4,5}
set_A.remove(2)
set_A.remove(8)



#  Remove an element from a set if it is a member. If the element is not a member, DO NOTHING.
set_A = {1,2,3,4,7}
set_A.discard(3)
set_A.discard(8)


#pop method : Remove and return an arbitrary set element.   Raises KeyError if the set is empty.
set_A.pop()






#A set contains an unordered collection of unique and immutable objects. Every element is unique (no duplicates) and must be immutable (which cannot be changed). 
# Proof: Tuple is allowed inside set whereas lists are not
list_obj = [323,32]
tuple_obj = (2121,323)

set_y = {10, tuple_obj}
set_x = {10, list_obj}



# Set Theory
odd_numbers = {1,3,5,7,9,11,13,15,17}
prime_numbers = {2,3,5,7,11,13,17}

odd_numbers.difference(prime_numbers)  #DIFFERENCE: the numbers which are ODD but not Prime
prime_numbers.difference(odd_numbers)  #DIFFERENCE: the numbers which are prime but not odd

odd_numbers.union(prime_numbers) #UNION: All unique numbers from both the sets
odd_numbers.intersection(prime_numbers) #INTERSECTION: Numbers which are both odd and prime.





#Iterating Through a Set:
great_student_qualities = {"provide rating","provides review/feedback","help peers", "complete the assignments/quizes"}
for quality in great_student_qualities:
     print("A good student always",quality)    
	

	
