#!/usr/bin/env python
# coding: utf-8

# In[ ]:


a_list = [1,2,42,4,66,7,22,12,32,3,100]

print( a_list[0] )
print( a_list[1] )
print( a_list[2] )
print( a_list[3] )
print( a_list[4] )
print( a_list[5] )
print( a_list[7] )
print( a_list[8] )
print( a_list[9] )
print( a_list[10] )


# In[ ]:





# In[ ]:





# In[ ]:


a_big_list = [32,3,4,35,333,64,213,53,4,5,23,5,4,54,3,2,4,3,3,4,44422,4,22,2,333,1,1,1,1,11,3,1,4,]

for item in a_big_list:
    print(item)


# In[ ]:





# In[ ]:





# In[ ]:


my_students = ["student1","student2","student3","studentN"]
for student in my_students:
  print("----------------")
  print("Hello", student)
  print("----------------")
print("######END OF FOR LOOP#######")


# In[ ]:





# In[ ]:


#Example:
# Function used are just dummy names. They dont exist in reality. 
# Hence this code cannot be executed successfully

computers=["Remote_Computer1","Remote_Computer2","Remote_Computer3","Remote_Computer4","Remote_Computer5", ]

for comp in computers:
    Do_Something(comp)
    


# In[ ]:


#Example:
# Function used are just dummy names. They dont exist in reality. 
# Hence this code cannot be executed successfully

computers=["Remote_Computer1","Remote_Computer2","Remote_Computer3","Remote_Computer4","Remote_Computer5", ]

for comp in computers:
    Analyze_log(comp)
    


# In[ ]:





# In[ ]:





# In[ ]:


a_big_list = [32,3,4,35,333,64,213,53,4,5,23,5,4,54,3,2,4,3,3,4,44422,4,22,2,333,1,1,1,1,11,3,1,4,]

for item in a_big_list:
    print(item)


# In[ ]:





# In[ ]:





# In[ ]:



list(range(10))


# In[ ]:





# In[ ]:


#for loop
for num in range(10):
 print(num)


# In[ ]:


#for loop
for num in range(10):
  pass


# In[ ]:


#for loop: Throws Error
for num in range(10):


# In[ ]:


help(range)


# In[ ]:





# In[ ]:


#for loop
for num in range(10):
 print(num)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


# using range(stop)
print(list(range(10)))


# In[ ]:





# In[ ]:


# using range(start, stop)
print(list(range(1, 13)))


# In[ ]:


# using range(start, stop, step)
print(list(range(3, 100, 6)))


# In[ ]:


#for loop

for num in range(1, 20, 2):
 print(num)


# In[ ]:





# In[ ]:





# In[ ]:


#Access list items by index number using Range Function
a_big_list = [32,3,4,35,333,64,213,53,4,5,23,5,4,54,3,2,4,3,3,4,44422,4,22,2,333,1,1,1,1,11,3,1,4,]

for i in range(10):
    print(a_big_list[i])


# In[ ]:





# In[ ]:


#Another Example:
a_big_list = [32,3,4,35,333,64,213,53,4,5,23,5,4,54,3,2,4,3,3,4,44422,4,22,2,333,1,1,1,1,11,3,1,4,]

for i in range(3,20,2):
    print(a_big_list[i])


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


#ODD NUMBERS:
print("Here is list of odd integers: ")
for i in range(1,100,2):
    print(i)
print("End of For loop")
print("===============")


# In[ ]:





# In[ ]:


#EVEN NUMBERS:
print("Here is list of even integers: ")
for i in range(10,80,2):
    print(i)
print("End of For loop")
print("===============")


# In[ ]:





# In[ ]:


#Table of 9
print("Here is multiplication table of 9: ")
for i in range(9,91,9):
    print(i)
print("===============")


# In[ ]:





# In[ ]:


#A Practical Application of For Loop:
# List of numbers
numbers = [6, 5, 3, 8, 4, 2, 5, 4, 11]

# variable to store the sum
sum = 0

# iterate over the list
for val in numbers:
	sum = sum+val

print("The sum is", sum)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:



for i in range(1,100,1):
    if(i==75):
        break
    else:
        print(i)
print("End of For loop")


# In[ ]:





# In[ ]:


# Example: Real World Usage
# Function used are just dummy names. They dont exist in reality. 
# Hence this code cannot be executed successfully

computers=["Remote_Computer1","Remote_Computer2","Remote_Computer3","Remote_Computer4","Remote_Computer5", ]

for comp in computers:
    if(not is_pingable(comp)):
        break
    else:
    call_some_important_logic(comp)
    


# In[ ]:





# In[ ]:





# In[ ]:



for i in range(10):
    if(i==7):
        continue
    else:
        print(i)
print("End of For loop")


# In[ ]:





# In[ ]:


# Example: Real World Usage

# Function used are just dummy names. They dont exist in reality. 
# Hence this code cannot be executed successfully
computers=["Remote_Computer1","Remote_Computer2","Remote_Computer3","Remote_Computer4","Remote_Computer5", ]

for comp in computers:
    if(not is_pingable(comp)):
        continue
    else:
    call_some_important_logic(comp)
    


# In[ ]:





# In[ ]:





# In[ ]:


#Example: While loop
i=0

while i<6:
  print(i,"Something")
  i += 1


# In[ ]:





# In[ ]:


#Example: While loop
counter = 5
while counter > 0:
 print(counter)
 counter -= 1


# In[ ]:





# In[ ]:




