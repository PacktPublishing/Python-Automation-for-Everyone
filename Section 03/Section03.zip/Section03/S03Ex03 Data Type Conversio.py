# Implict data type conversion

#Example:  Python promotes conversion of lower datatype (integer) to higher data type (float) to avoid data loss.

varA = 20
varB = 2.56
result = 0

print("datatype of varA:",type(varA))
print("datatype of varB:",type(varB))
print("datatype of result:",type(result))

result = varA + varB

print("Value of result:",result)
print("datatype of result:",type(result))	



#TypeError: unsupported operand type(s) for +: 'int' and 'str'
"123" + 321

# Converting int to string
"123" + str("321")

#Converting string to int
123 + int("321")


# a.) Explicit type conversion from int to float
num1 = 3
num2 = 2

float_sum = float(num1 + num2) 
print(float_sum)


# b.)Explicit type conversion from float to int
num1_float = 3.3
num2_float = 2.0

int_sum = int(num1_float + num2_float) 
print(int_sum)




Type Conversion
Function	Description
ascii()	Returns a string containing a printable representation of an object
bin()	Converts an integer to a binary string
bool()	Converts an argument to a Boolean value
chr()	Returns string representation of character given by integer argument
complex()	Returns a complex number constructed from arguments
float()	Returns a floating-point object constructed from a number or string
hex()	Converts an integer to a hexadecimal string
int()	Returns an integer object constructed from a number or string
oct()	Converts an integer to an octal string
ord()	Returns integer representation of a character
repr()	Returns a string containing a printable representation of an object
str()	Returns a string version of an object
type()	Returns the type of an object or creates a new type object



Type conversion
Type conversion in Python by example:

v1 = int(7.7) # 7
v2 = int(-3.9) # -3
v3 = int("7") # 7
v4 = int("11", 16) # 17, base 16
v5 = long(7)
v6 = float(7) # 7.0
v7 = float("7.7") # 7.7
v8 = float("7.7E-7") # 0.077
v9 = float(False) # 0.0
vA = float(True) # 1.0
vB = str(4.5) # "4.5"
vC = str([1, 3, 5]) # "[1, 3, 5]"
vD = bool(0) # False; 
vE = bool(3) # True
vF = bool([]) # False - empty list
vG = bool([False]) # True - non-empty list
vH = bool({}) # False - empty dict; same for empty tuple
vI = bool("") # False - empty string
vJ = bool(" ") # True - non-empty string
vK = bool(None) # False
vL = bool(len) # True
vM = set([1, 7])
vN = list(vM)
vO = list({1: "a", 7: "b"}) # dict -> list of keys
vP = tuple(vN)
vQ = list("abc") # ['a', 'b', 'c']