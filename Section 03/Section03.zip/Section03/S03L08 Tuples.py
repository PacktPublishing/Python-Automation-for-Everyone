#!/usr/bin/env python
# coding: utf-8

# In[ ]:


list_obj_vijay_courses = ['Learning Task Automation',"Advanced Scripting & Tool Making", "Active Directory" , "Python"]


# In[ ]:





# In[ ]:


tuple_Vijay_Courses = ( 'Learning Task Automation',"Advanced Scripting & Tool Making", "Active Directory" , "Python" )
tuple2 = (2018, 2019, "Python is Awesome")


# In[ ]:





# In[ ]:


#Type of object
type(tuple_Vijay_Courses)


# In[ ]:





# In[ ]:


#Directory function
print(dir(tuple_Vijay_Courses))


# In[ ]:


#Directory function
print(dir(list_obj_vijay_courses))


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


tuple_numbers = (2,3,4,5,6,2,2,)

#Count Method :  return number of occurrences of value
print(tuple_numbers.count(2))
print(tuple_numbers.count(5))


# In[ ]:





# In[ ]:


#T.index(value, [start, [stop]]) -> integer -- return first index of value. Raises ValueError if the value is not present.
print(tuple_numbers.index(2))
print(tuple_numbers.index(5))


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


print(tuple_Vijay_Courses)           	# Prints complete tuple
print(tuple_Vijay_Courses[0])       	# Prints first element of the tuple
print(tuple_Vijay_Courses[1:3])      	# Prints elements starting from 2nd till 3rd 
print(tuple_Vijay_Courses[2:] )      	# Prints elements starting from 3rd element

print(tuple_Vijay_Courses * 2)   		# Prints tuple two times
print(tuple_Vijay_Courses + tuple2) 	# Prints concatenated lists


# In[ ]:





# In[ ]:





# In[ ]:





# In[41]:


a = (111)
print ( type(a) )

b = ("test")
print ( type(b) )


# In[ ]:





# In[42]:


#Create a tuple of single item
tiny_tuple = (10,)

print ( type(tiny_tuple) )


# In[ ]:





# In[ ]:





# In[43]:


#Iterating Through a Tuple:
python_students = ("male1","male2","female1","female2")
for student in python_students:
     print("Hello",student)    


# In[ ]:




