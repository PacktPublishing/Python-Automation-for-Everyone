tuple_Vijay_Courses = ( 'PowerShell', "Active Directory" , "Python",  )
tuple2 = (2018, 2019, "Python is Awesome")


#Type of object
type(tuple_Vijay_Courses)

#Directory function
dir(tuple_Vijay_Courses)

#Print each dir item in new line:
for i in dir(tuple_Vijay_Courses): print(i) 

 

tuple_Vijay_Courses           	# Prints complete tuple
tuple_Vijay_Courses[0]       	# Prints first element of the tuple
tuple_Vijay_Courses[1:3]      	# Prints elements starting from 2nd till 3rd 
tuple_Vijay_Courses[2:]       	# Prints elements starting from 3rd element
tuple_Vijay_Courses * 2   		# Prints tuple two times
tuple_Vijay_Courses + tuple2 	# Prints concatenated lists



tuple_numbers = (2,3,4,5,6,2,2,)

#Count Method :  return number of occurrences of value
tuple_numbers.count(2)
tuple_numbers.count(5)

#T.index(value, [start, [stop]]) -> integer -- return first index of value. Raises ValueError if the value is not present.
tuple_numbers.index(2)
tuple_numbers.index(5)


#Create a tuple of single item
tiny_tuple = (10,)


#Iterating Through a Tuple:
python_students = ("male1","male2","female1","female2")
for student in python_students:
     print("Hello",student)    
	 

