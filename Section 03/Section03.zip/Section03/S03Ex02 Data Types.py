
#Boolean
type(True) 	# <class 'bool'>
type(False) # <class 'bool'>

my_string = "my favorite student"
my_string.isupper()		#test if string contains upper case
my_string.islower() 	#test if string contains lower case



#NUMBERS
num = 5
print(num, "is of type", type(num))

num = 2.0
print(num, "is of type", type(num))

num = 1+2j
print(num, "is of type", type(num))
#print(num, "is complex number?", isinstance(1+2j,complex))

num.real  	#real part of the complex number
num.imag	#imaginary part of the complex number


# 3000000.0  
# = 3 * 10pow(6) 0r 0.3 * 10pow(7)
# = .3e7
# = 3000000.0   
>>> type(.3e7)
<class 'float'>

# 0.00092
# = 92/100000 
# = 92 * 10pow(-5)
# = 9.2 * 10pow(-4)
9.2e-4



