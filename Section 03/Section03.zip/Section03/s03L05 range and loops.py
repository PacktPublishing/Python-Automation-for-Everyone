list(range(0))


list(range(6))


# using range(stop)
print(list(range(10)))

# using range(start, stop)
print(list(range(1, 10)))


# using range(start, stop, step)
print(list(range(1, 10, 2)))


#for loop

for num in range(1, 20, 2):
 print(num)


 
 
my_students = ["student1","student2","student3","studentN"]
for student in my_students:
 print(student)

 
 
my_students = ["student1","student2","student3","studentN"]
for student in my_students:
 print("Hello", student)

 
 
# List of numbers
numbers = [6, 5, 3, 8, 4, 2, 5, 4, 11]

# variable to store the sum
sum = 0

# iterate over the list
for val in numbers:
	sum = sum+val

# Output: The sum is 48
print("The sum is", sum)



#while loop
i=0
while i<10:
  print(i,"Something")
  i += 1
	


count = 0
while count < 5:
 print(count)
 count += 1 
	
	